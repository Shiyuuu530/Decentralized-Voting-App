export const contractABI = require('./voting.json');
export const contractAddress = '0xFbef15afE00c67f64E3cbf75b101f3324E8357Cd';